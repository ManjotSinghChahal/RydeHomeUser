package com.example.rydehomeuser.ui.activities.home.fragment.contactList

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.rydehomeuser.R

class ContactListAdapter(val context : Context) : RecyclerView.Adapter<ContactListAdapter.ViewHolder>()
{
    override fun onCreateViewHolder(container: ViewGroup, p1: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.contactlist_adapter,container,false))
    }

    override fun getItemCount(): Int {
       return 15
    }

    override fun onBindViewHolder(p0: ViewHolder, p1: Int) {
    }


    inner class ViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView)
    {

    }
}