package com.example.rydehomeuser.ui.activities.signUp.fragments.bussinessId


import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.home.Home
import com.example.rydehomeuser.ui.activities.signUp.SignUp
import kotlinx.android.synthetic.main.fragment_bussiness_id.view.*


class BussinessID : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       val view = inflater.inflate(R.layout.fragment_bussiness_id, container, false)

      clickListener(view)


        return view
    }

    fun clickListener(view : View)
    {
        SignUp.signUpBackIcon.setOnClickListener {
            activity?.let { it.onBackPressed() }

        }
            view.txt_businessId_next.setOnClickListener {
                startActivity(Intent(activity, Home::class.java))
                (activity as AppCompatActivity).finish()
                (activity as AppCompatActivity).overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            }


    }


}
