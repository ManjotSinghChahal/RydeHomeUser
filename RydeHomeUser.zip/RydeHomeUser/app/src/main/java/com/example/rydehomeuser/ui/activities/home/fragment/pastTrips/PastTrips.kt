package com.example.rydehomeuser.ui.activities.home.fragment.pastTrips


import android.annotation.SuppressLint
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup


import com.example.rydehomeuser.R


class PastTrips() : Fragment() {

    @SuppressLint("ValidFragment")
    constructor( value: String) : this() {

    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_past_trips, container, false)



        setUp(view)



        return view
    }

    fun setUp(view : View)
    {
        val recyclerviewPastTrips = view.findViewById(R.id.recyclerview_past_trips) as RecyclerView
        recyclerviewPastTrips.layoutManager = LinearLayoutManager(activity)
        activity?.let {
            recyclerviewPastTrips.adapter = PastTripAdapter(it)
        }
    }






}
