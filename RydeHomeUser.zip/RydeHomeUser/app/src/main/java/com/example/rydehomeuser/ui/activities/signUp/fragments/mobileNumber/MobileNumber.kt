package com.example.rydehomeuser.ui.activities.signUp.fragments.mobileNumber


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.signUp.SignUp
import com.example.rydehomeuser.ui.activities.signUp.fragments.otp.Otp
import kotlinx.android.synthetic.main.fragment_mobile_number.view.*


class MobileNumber : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
       val view = inflater.inflate(R.layout.fragment_mobile_number, container, false)


        SignUp.signUpBackIcon.visibility = View.GONE
        SignUp.signUpCrossIcon.visibility = View.VISIBLE
        SignUp.title_signUp.visibility = View.VISIBLE
        SignUp.title_signUp.text = getString(R.string.mobilenum)


        clickListener(view)

        view.next_mobileNum.setOnClickListener {
            (activity as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.container_signup,Otp()).addToBackStack(null).commit()
        }




        return view
    }


    fun clickListener(view : View)
    {
        SignUp.signUpCrossIcon.setOnClickListener {
            activity?.let { it.onBackPressed() }
        }

    }


}
