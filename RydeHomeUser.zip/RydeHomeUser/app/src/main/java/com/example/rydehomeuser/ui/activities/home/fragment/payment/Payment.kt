package com.example.rydehomeuser.ui.activities.home.fragment.payment


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.rydehomedriver.utils.GlobalHelper

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.home.Home
import com.example.rydehomeuser.ui.activities.home.fragment.addPaymentMethod.AddPaymentMethod
import com.example.rydehomeuser.ui.activities.home.fragment.addPromoCode.AddPromoCode
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.fragment_payment.view.*


class Payment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
      val view = inflater.inflate(R.layout.fragment_payment, container, false)

        GlobalHelper.setToolbar(getString(R.string.payment_s),homeCrossIconVis= true)
        clickListener(view)


        return view
    }



    fun clickListener(view : View)
    {
        view.rel_addBussinessProfile.setOnClickListener {
            view.rel_addBussinessProfile.visibility = View.GONE
            view.rel_enterBussinessID.visibility = View.VISIBLE
            Home.homeCrossIcon.visibility = View.GONE
            Home.homeBackIcon.visibility = View.VISIBLE
        }


        Home.homeCrossIcon.setOnClickListener {
            activity?.let { it.onBackPressed() }
        }

        Home.homeBackIcon.setOnClickListener {
            view.rel_addBussinessProfile.visibility = View.VISIBLE
            view.rel_enterBussinessID.visibility = View.GONE
            Home.homeCrossIcon.visibility = View.VISIBLE
            Home.homeBackIcon.visibility = View.GONE
        }


        view.txtview_addPromoCode.setOnClickListener {
            (activity as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.container_map,AddPromoCode()).addToBackStack(null).commit()
        }

        view.txtview_addPaymentMethod.setOnClickListener {
            (activity as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.container_map,AddPaymentMethod()).addToBackStack(null).commit()
        }
    }


}
