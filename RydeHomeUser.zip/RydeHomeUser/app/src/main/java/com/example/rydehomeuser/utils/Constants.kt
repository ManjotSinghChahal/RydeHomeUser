package com.example.rydehomedriver.utils

object Constants {
  //  val DOCS_DATA : String = "docs_data"

    val CONTACT_LIST : String = "contact_list"
}