package com.example.rydehomedriver.ui.activities.splashScreen

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import com.example.rydehomedriver.utils.GrantPermissions
import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.signUp.SignUp


class SplashActivity : Activity(), SplashView {

    private val PermissionsRequestCode = 101
    lateinit var presenter: SplashPresenter
    lateinit var managePermissions: GrantPermissions
    private var mDelayHandler: Handler? = null
    private val SPLASH_DELAY: Long = 2000 //2 seconds


    override fun onCreate(savedInstanceState: Bundle?) {
       /* requestWindowFeature(FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)*/
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_activity)





        presenter = SplashPresenter(this, SplashInteractor())


        val list = listOf<String>(
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        // Initialize a new instance of ManagePermissions class
        managePermissions = GrantPermissions(this, list, PermissionsRequestCode,this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            managePermissions.checkPermissions()
        else
            presenter.onTimeOut()
    }


    override fun onHandleTimeout() {

        mDelayHandler = Handler()
        //Navigate with delay
        mDelayHandler!!.postDelayed(mRunnable, SPLASH_DELAY)

    }


    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {



        when (requestCode) {
            PermissionsRequestCode -> {
                val isPermissionsGranted = managePermissions
                    .processPermissionsResult(requestCode, permissions, grantResults)

                presenter.onTimeOut()

                if (isPermissionsGranted) {
                    //  toast("Permissions granted.")
                } else {
                    //  toast("Permissions denied.")
                }
                return
            }
        }

    }

    internal val mRunnable: Runnable = Runnable {
        if (!isFinishing) {
            val intent = Intent(applicationContext, SignUp::class.java)
            startActivity(intent)
            finish()
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        }
    }

    public override fun onDestroy() {

        if (mDelayHandler != null)
            mDelayHandler!!.removeCallbacks(mRunnable)

        super.onDestroy()
    }





}