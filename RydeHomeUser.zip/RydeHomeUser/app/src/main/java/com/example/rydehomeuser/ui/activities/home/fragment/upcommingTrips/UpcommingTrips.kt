package com.example.rydehomeuser.ui.activities.home.fragment.upcommingTrips


import android.annotation.SuppressLint
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.home.fragment.pastTrips.PastTripAdapter


class UpcommingTrips()  : Fragment() {

    @SuppressLint("ValidFragment")
    constructor( value: String) : this() {

    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
       val view = inflater.inflate(R.layout.fragment_upcomming_trips, container, false)


        setUp(view)

        return view
    }



    fun setUp(view : View)
    {
        val recyclerviewUpcomingTrips = view.findViewById(R.id.recyclerview_upcomming_trips) as RecyclerView
        recyclerviewUpcomingTrips.layoutManager = LinearLayoutManager(activity)
        activity?.let {
            recyclerviewUpcomingTrips.adapter = PastTripAdapter(it)
        }
    }



}
