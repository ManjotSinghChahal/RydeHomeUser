package com.example.rydehomeuser.ui.activities.home.fragment.help


import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import com.example.rydehomedriver.utils.GlobalHelper
import com.example.rydehomedriver.utils.conCat

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.home.Home
import kotlinx.android.synthetic.main.fragment_help.*
import kotlinx.android.synthetic.main.fragment_help.view.*


class Help : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
       val view = inflater.inflate(R.layout.fragment_help, container, false)



        GlobalHelper.setToolbar(getString(R.string.help),homeCrossIconVis = true)
        setUp(view)
        clickLstener(view)


        return view
    }


    fun clickLstener(view : View)
    {
        Home.homeCrossIcon.setOnClickListener {
            activity?.onBackPressed()
        }

    }

    fun setUp(view : View)
    {

        val webviewHelp: WebView = view.findViewById(R.id.webview_help) as WebView

        webviewHelp.settings.javaScriptEnabled = true
        webviewHelp.loadUrl("https://maps.googleapis.com/maps/api/staticmap?center=Brooklyn+Bridge,New+York,NY&zoom=13&size=600x300&maptype=roadmap\n" +
                "        &markers=color:blue%7Clabel:S%7C40.702147,-74.015794&markers=color:green%7Clabel:G%7C40.711614,-74.012318\n" +
                "        &markers=color:red%7Clabel:C%7C40.718217,-73.998284\n" +
                "        &key=AIzaSyBfffgfmuX2uumW09fqJZKbEHOnPqSPzaE")

       "60.41".conCat(view,view.amount_help)


    }


}
