package com.example.rydehomedriver.ui.activities.splashScreen

interface SplashView {

    fun onHandleTimeout()
}