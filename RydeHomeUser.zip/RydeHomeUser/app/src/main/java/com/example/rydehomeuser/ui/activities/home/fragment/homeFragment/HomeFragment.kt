package com.example.rydehomeuser.ui.activities.home.fragment.homeFragment

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.rydehomedriver.utils.GlobalHelper
import com.example.rydehomeuser.R
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions


class HomeFragment : Fragment() , OnMapReadyCallback {
    private var mMap: GoogleMap? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
       val view  = inflater.inflate(R.layout.fragment_home, container, false)


        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)


        GlobalHelper.setToolbar(getString(R.string.home),homeMenuIconVis = true,drawerSwipeable = true)




        return view
    }


    override fun onMapReady(googleMap: GoogleMap?)
    {

        this.mMap = googleMap

        val position = LatLng(30.7046, 76.7179)
        mMap?.addMarker(
            MarkerOptions()
                .position(position)
                .title("Cqlsys Location"))
        mMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(position, 10f))

    }


}
