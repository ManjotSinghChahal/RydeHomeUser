package com.example.rydehomedriver.ui.activities.splashScreen

open class SplashInteractor {


    interface  OnStart
    {
        fun onCounterStart()
    }

}