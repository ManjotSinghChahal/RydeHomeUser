package com.example.rydehomeuser.ui.activities.signUp

import android.os.Bundle
import android.support.design.chip.Chip
import android.support.design.chip.ChipGroup
import android.support.v7.app.AppCompatActivity
import android.widget.ImageView
import android.widget.TextView
import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.signUp.fragments.chooseType.ChooseType
import kotlinx.android.synthetic.main.fragment_account_settings.*

class SignUp : AppCompatActivity()
{

    companion object
    {
        lateinit var signUpBackIcon : ImageView
        lateinit var signUpCrossIcon : ImageView
        lateinit var title_signUp : TextView
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.signup)

        setId()





        supportFragmentManager.beginTransaction().replace(R.id.container_signup,ChooseType()).commit()


    }

    fun setId()
    {
        signUpBackIcon = findViewById<ImageView>(R.id.signUp_back_icon)
        signUpCrossIcon = findViewById<ImageView>(R.id.signUp_cross_icon)
        title_signUp = findViewById<TextView>(R.id.title_signUp)


    }





}