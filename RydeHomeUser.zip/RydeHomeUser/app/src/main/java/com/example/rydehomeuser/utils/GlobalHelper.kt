package com.example.rydehomedriver.utils

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.support.v4.widget.DrawerLayout
import android.view.View
import android.widget.RelativeLayout
import com.example.rydehomeuser.ui.activities.home.Home
import kotlinx.android.synthetic.main.fragment_account_settings.view.*

object GlobalHelper
{

    val euro by lazy {  "\u20ac" }
    val pound by lazy { "\u00a3" }

    fun changeTextColor (text : String,colorCode : String) : String
    {
        return   "<font color='$colorCode'>$text</font>"
    }


    fun setToolbar(value : String,homeMenuIconVis : Boolean = false,homeBackIconVis : Boolean = false, relToggleVis: Boolean = false,homeCrossIconVis : Boolean = false,drawerSwipeable : Boolean = false,relHomeDone : Boolean = false)
    {
        Home.titleHome.text = value
        if (homeMenuIconVis) Home.homeMenuIcon.visibility = View.VISIBLE else Home.homeMenuIcon.visibility = View.GONE
        if (homeBackIconVis)  Home.homeBackIcon.visibility = View.VISIBLE else  Home.homeBackIcon.visibility = View.GONE
        if (relToggleVis) Home.relToggle.visibility = View.VISIBLE else Home.relToggle.visibility = View.GONE
        if (homeCrossIconVis) Home.homeCrossIcon.visibility = View.VISIBLE else Home.homeCrossIcon.visibility = View.GONE
        if (relHomeDone) Home.relDoneHome.visibility = View.VISIBLE else Home.relDoneHome.visibility = View.GONE
        if (!drawerSwipeable)   Home.drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)

    }


    fun changeBackground(layout: RelativeLayout, color: Int)
    {
        val gd = GradientDrawable()
        gd.shape = GradientDrawable.RECTANGLE
        gd.setColor(Color.TRANSPARENT)
        gd.setStroke(4, color)
        gd.cornerRadius = 80.0f // border corner radius
        layout.rel_toggle.setBackground(gd)

    }


}