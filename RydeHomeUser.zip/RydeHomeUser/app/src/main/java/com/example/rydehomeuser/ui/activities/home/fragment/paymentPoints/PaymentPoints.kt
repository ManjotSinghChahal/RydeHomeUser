 package com.example.rydehomeuser.ui.activities.home.fragment.paymentPoints


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.view.ViewPager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.rydehomedriver.utils.GlobalHelper
import com.example.rydehomedriver.utils.conCat

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.home.Home
import com.example.rydehomeuser.utils.CommonPagerAdapter
import kotlinx.android.synthetic.main.fragment_payment_points.view.*


 class PaymentPoints : Fragment() {
    lateinit var  viewPager : ViewPager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_payment_points, container, false)

        setValues(view)
        clickListener(view)


        GlobalHelper.setToolbar(getString(R.string.payment_s),homeCrossIconVis =  true)

        return view
    }



    fun setValues(view : View)
    {



        viewPager = view.findViewById(R.id.viewPager_payment) as ViewPager
        val adapter = CommonPagerAdapter()

        // insert page ids
        adapter.insertViewId(R.id.linLay_help_payment)
        adapter.insertViewId(R.id.linLay_receipt_payment)

        view.view_receipt_payment.visibility = View.GONE
        view.view_help_payment.visibility = View.VISIBLE


        // attach adapter to viewpager
        viewPager.setAdapter(adapter)
        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener
        {
            override fun onPageScrollStateChanged(pos: Int) {

            }

            override fun onPageScrolled(pos1: Int, pos3: Float, pos2: Int) {

            }

            override fun onPageSelected(pos: Int) {
                if (pos==0)
                {
                    view.view_receipt_payment.visibility = View.GONE
                    view.view_help_payment.visibility = View.VISIBLE

                }
                else
                {
                    view.view_receipt_payment.visibility = View.VISIBLE
                    view.view_help_payment.visibility = View.GONE
                }
            }

        })







        "60.41".conCat(view, view.amount_trip_payment)
        "60.00".conCat(view, view.tripFare_payment)
        "60.00".conCat(view, view.subTotal_payment)
        "60.00".conCat(view, view.total_payment)
        "60.00".conCat(view, view.paidByCard_payment)



        view.webview_map_payment.settings.javaScriptEnabled = true
        view.webview_map_payment.loadUrl("https://maps.googleapis.com/maps/api/staticmap?center=Brooklyn+Bridge,New+York,NY&zoom=13&size=600x300&maptype=roadmap\n" +
                "        &markers=color:blue%7Clabel:S%7C40.702147,-74.015794&markers=color:green%7Clabel:G%7C40.711614,-74.012318\n" +
                "        &markers=color:red%7Clabel:C%7C40.718217,-73.998284\n" +
                "        &key=AIzaSyBfffgfmuX2uumW09fqJZKbEHOnPqSPzaE")

    }


    fun clickListener(view: View )
    {
        Home.homeCrossIcon.setOnClickListener {
            if (view.next_pay_points.text.toString().trim().equals("PAY"))
            {
                view.rel_totalAmount.visibility = View.GONE
                view.next_pay_points.text = getString(R.string.next)
            }
            else
            activity?.onBackPressed()
        }


        view.rel_receipt_payment.setOnClickListener {
            viewPager.currentItem = 1
        }

        view.rel_help_payment.setOnClickListener {
            viewPager.currentItem = 0
        }

        view.next_pay_points.setOnClickListener {

            if (view.next_pay_points.text.toString().trim().equals("PAY"))
            {

            }
            else if (view.next_pay_points.text.toString().trim().equals("NEXT"))
            {
              view.rel_totalAmount.visibility = View.VISIBLE
              view.next_pay_points.text = getString(R.string.pay)
            }

        }
    }


}
