package com.example.rydehomeuser.ui.activities.home.fragment.contactList


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.rydehomedriver.utils.Constants
import com.example.rydehomedriver.utils.GlobalHelper

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.home.Home
import com.example.rydehomeuser.ui.models.ContactModel


class ContactList : Fragment() {

     var contactModelArrayList: ArrayList<ContactModel>? = null

     override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
      val view =  inflater.inflate(R.layout.fragment_contact_list, container, false)


          GlobalHelper.setToolbar(getString(R.string.contacts),homeBackIconVis = true,relHomeDone = true)


         var bundle = arguments
         bundle?.let {
             contactModelArrayList =   it.getParcelableArrayList<ContactModel>(Constants.CONTACT_LIST)

         }



        setValues(view)
        clickListener(view)



        return view
    }


    fun setValues(view : View)
    {

        val recyclerviewContactList = view.findViewById(R.id.recyclerview_contactList) as RecyclerView
        recyclerviewContactList.layoutManager = LinearLayoutManager(activity)
        recyclerviewContactList.adapter = activity?.let { ContactListAdapter(it) }

    }

    fun clickListener(view : View)
    {
           Home.homeBackIcon.setOnClickListener {
               activity?.let { it.onBackPressed() }
           }
    }


    override fun onDestroy() {
        super.onDestroy()
        Home.relDoneHome.visibility = View.GONE
    }


}
