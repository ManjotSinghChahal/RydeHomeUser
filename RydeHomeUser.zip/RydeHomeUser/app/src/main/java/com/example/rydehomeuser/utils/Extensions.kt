package com.example.rydehomedriver.utils

import android.content.Context
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentTransaction
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.TextView
import android.widget.Toast


fun String.conCat(view: View, txtview: TextView, amountBalance: Boolean = true) {
    if (amountBalance) txtview.text = "${GlobalHelper.pound} $this" else txtview.text = "-${GlobalHelper.pound} $this"
}


fun String.conCatReturn(amountBalance: Boolean = true) :String {
    return if (amountBalance)  "${GlobalHelper.pound} $this" else "-${GlobalHelper.pound} $this"
}


fun Context.showToast(context: Context, msg: String, duration: Int = Toast.LENGTH_SHORT): Toast {
    return Toast.makeText(context, msg, duration)
}


inline fun FragmentManager.inTransaction(func: FragmentTransaction.() -> Unit) {
    val fragmentTransaction = beginTransaction()
    fragmentTransaction.func()
    fragmentTransaction.commit()
}


fun AppCompatActivity.replaceFragment(fragment: Fragment, frameId: Int) {
    supportFragmentManager.inTransaction{replace(frameId, fragment)}
}






