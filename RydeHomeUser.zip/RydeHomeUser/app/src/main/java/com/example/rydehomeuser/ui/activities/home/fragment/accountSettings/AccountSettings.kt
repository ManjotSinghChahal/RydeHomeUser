package com.example.rydehomeuser.ui.activities.home.fragment.accountSettings



import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.rydehomeuser.R
import kotlinx.android.synthetic.main.fragment_account_settings.view.*
import com.example.rydehomedriver.utils.GlobalHelper
import com.example.rydehomeuser.ui.activities.home.Home
import android.graphics.Paint
import android.provider.ContactsContract
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.example.rydehomedriver.utils.Constants.CONTACT_LIST
import com.example.rydehomeuser.ui.activities.home.fragment.contactList.ContactList
import com.example.rydehomeuser.ui.activities.home.fragment.editAccount.EditAccount
import com.example.rydehomeuser.ui.models.ContactModel
import kotlin.collections.ArrayList


class AccountSettings : Fragment() {
    private var contactModelArrayList: ArrayList<ContactModel>? = null
    private var tagList = arrayListOf<String>()

  //  lateinit var  chipGroup : ChipGroup


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_account_settings, container, false)


        GlobalHelper.setToolbar(getString(R.string.account_settings),homeCrossIconVis = true)
        clickListener(view)
       // setTag(tagList,view)
      //  createChip(view)
      //   chipGroup = view.findViewById(R.id.tag_group) as ChipGroup







        loadContacts()


    view.select_contacts_setting.paintFlags = view.select_contacts_setting.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG
    view.add_more_setting.paintFlags = view.add_more_setting.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG


        return view
    }


    fun clickListener(view : View)
    {
        view.rel_switch_left_setting.setOnClickListener {
            GlobalHelper.changeBackground(view.rel_toggle,resources.getColor(R.color.colorAppTheme ))

            view.select_contacts_setting.visibility = View.VISIBLE

            view.img_switch_left_setting.visibility = View.VISIBLE
            view.img_switch_right_setting.visibility = View.GONE
        }

        view.rel_switch_right_setting.setOnClickListener {
            GlobalHelper.changeBackground(view.rel_toggle,resources.getColor(R.color.gray))

            view.select_contacts_setting.visibility = View.GONE

            view.img_switch_left_setting.visibility = View.GONE
            view.img_switch_right_setting.visibility = View.VISIBLE


        }


        Home.homeCrossIcon.setOnClickListener {
            activity?.let { it.onBackPressed() }
        }

        view.lin_addHome.setOnClickListener {
         (activity as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.container_map,EditAccount()).addToBackStack(null).commit()
        }



        view.select_contacts_setting.setOnClickListener {

         //   addChip()


            val bundle  = Bundle()
            bundle.putParcelableArrayList(CONTACT_LIST,contactModelArrayList)
            val contactList : ContactList = ContactList()
            contactList.arguments = bundle
            (context   as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.container_map, ContactList()).addToBackStack(null).commit()
        }

    }


    //----------------------------load contacts---------------------------




 fun loadContacts() {

     contactModelArrayList = arrayListOf<ContactModel>()

     val phones = activity?.contentResolver?.query(
         ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
         null,
         null,
         null,
         ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
     )
     while (phones!!.moveToNext()) {
         val name = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
         val phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))

         val contactModel = ContactModel(name,phoneNumber)
             // contactModel.setNames(name)
       //  contactModel.setNumbers(phoneNumber)
         contactModelArrayList!!.add(contactModel)
         Log.e("name------->>", name + "  " + phoneNumber)
     }
     phones.close()
 }





/*    private fun createChip(view : View){

    }


  fun addChip()
  {
      var chip = Chip(activity)
      chip.text = "hello World"
      chip.isCloseIconEnabled = true
      //  chip.background = getColor(R.color.colorAccent)
      chipGroup.addView(chip)
  }*/


}
