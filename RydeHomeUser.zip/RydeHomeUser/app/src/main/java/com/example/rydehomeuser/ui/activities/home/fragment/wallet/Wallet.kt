package com.example.rydehomeuser.ui.activities.home.fragment.wallet


import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.rydehomedriver.utils.GlobalHelper

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.home.Home


class Wallet : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
       val view = inflater.inflate(R.layout.fragment_wallet, container, false)

        GlobalHelper.setToolbar(getString(R.string.wallet),homeBackIconVis = true)
        clickListener(view)

        return view
    }


    fun clickListener(View : View)
    {

        Home.homeBackIcon.setOnClickListener {
            activity?.let { it.onBackPressed() }
        }
    }


}
