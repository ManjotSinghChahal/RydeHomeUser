package com.example.rydehomeuser.ui.activities.home.fragment.tripDetails


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.view.ViewPager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewParent
import com.example.rydehomedriver.utils.GlobalHelper
import com.example.rydehomedriver.utils.conCat

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.home.Home
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.fragment_trip_details.view.*

import com.example.rydehomeuser.utils.CommonPagerAdapter

import kotlinx.android.synthetic.main.fragment_trip_details.*


class TripDetails : Fragment() {

lateinit var  viewPager : ViewPager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
       val  view = inflater.inflate(R.layout.fragment_trip_details, container, false)

        setValues(view)
        clickListener(view)


        GlobalHelper.setToolbar(getString(R.string.trip_details),homeBackIconVis =  true)

        return view
    }




    fun setValues(view : View)
    {



        viewPager = view.findViewById(R.id.viewPager_tripDetails) as ViewPager
        val adapter = CommonPagerAdapter()

      // insert page ids
        adapter.insertViewId(R.id.linLay_help)
        adapter.insertViewId(R.id.linLay_receipt)

        view.view_receipt.visibility = View.GONE
        view.view_help.visibility = View.VISIBLE


        // attach adapter to viewpager
        viewPager.setAdapter(adapter)
        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener
        {
            override fun onPageScrollStateChanged(pos: Int) {

            }

            override fun onPageScrolled(pos1: Int, pos3: Float, pos2: Int) {

            }

            override fun onPageSelected(pos: Int) {
               if (pos==0)
               {
                   view.view_receipt.visibility = View.GONE
                   view.view_help.visibility = View.VISIBLE

               }
                else
               {
                   view.view_receipt.visibility = View.VISIBLE
                   view.view_help.visibility = View.GONE
               }
            }

        })







        "60.41".conCat(view, view.amount_trip_details)
        "60.00".conCat(view, view.tripFare_trip_details)
        "60.00".conCat(view, view.subTotal_trip_details)
        "60.00".conCat(view, view.total_trip_details)
        "60.00".conCat(view, view.paidByCard_trip_details)



        view.webview_map_detail.settings.javaScriptEnabled = true
        view.webview_map_detail.loadUrl("https://maps.googleapis.com/maps/api/staticmap?center=Brooklyn+Bridge,New+York,NY&zoom=13&size=600x300&maptype=roadmap\n" +
                "        &markers=color:blue%7Clabel:S%7C40.702147,-74.015794&markers=color:green%7Clabel:G%7C40.711614,-74.012318\n" +
                "        &markers=color:red%7Clabel:C%7C40.718217,-73.998284\n" +
                "        &key=AIzaSyBfffgfmuX2uumW09fqJZKbEHOnPqSPzaE")

    }


    fun clickListener(view: View )
    {
        Home.homeBackIcon.setOnClickListener {
            activity?.onBackPressed()
        }


        view.rel_receipt.setOnClickListener {
            viewPager.currentItem = 1
        }

        view.rel_help.setOnClickListener {
            viewPager.currentItem = 0
        }
    }



}
