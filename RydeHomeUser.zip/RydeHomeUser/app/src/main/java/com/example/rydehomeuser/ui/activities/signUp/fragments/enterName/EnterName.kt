package com.example.rydehomeuser.ui.activities.signUp.fragments.enterName


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.signUp.SignUp
import com.example.rydehomeuser.ui.activities.signUp.fragments.bussinessId.BussinessID
import kotlinx.android.synthetic.main.fragment_enter_name.view.*

class EnterName : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_enter_name, container, false)


        SignUp.signUpBackIcon.visibility = View.VISIBLE
        SignUp.signUpCrossIcon.visibility = View.GONE
        SignUp.title_signUp.visibility = View.VISIBLE
        SignUp.title_signUp.text = getString(R.string.sign_up)

        clickListener(view)


        return view
    }


    fun clickListener(view: View) {
        view.txt_name_next.setOnClickListener {
            (activity as AppCompatActivity).supportFragmentManager.beginTransaction()
                .replace(R.id.container_signup, BussinessID()).addToBackStack(null).commit()
        }

        SignUp.signUpBackIcon.setOnClickListener {
            activity?.let { it.onBackPressed() }
        }


    }
}
