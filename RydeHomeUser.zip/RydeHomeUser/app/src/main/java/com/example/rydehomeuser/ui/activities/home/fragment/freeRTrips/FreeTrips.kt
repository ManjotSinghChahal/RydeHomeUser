package com.example.rydehomeuser.ui.activities.home.fragment.freeRTrips


import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.rydehomedriver.utils.GlobalHelper
import com.example.rydehomedriver.utils.conCatReturn

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.home.Home
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.fragment_free_trips.view.*


class FreeTrips : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
       val view = inflater.inflate(R.layout.fragment_free_trips, container, false)


        GlobalHelper.setToolbar(getString(R.string.free_trips),homeCrossIconVis = true)
        setValues(view)
        clickListener(view)

        return view
    }


    fun setValues(view : View)
    {
        val amt = getString(R.string.share_free_rides)+" "+"30.00".conCatReturn() +" each!"
        view.txtview_share_free_rides.text = amt
    }

    fun clickListener(view : View)
    {
        Home.homeCrossIcon.setOnClickListener {
            activity?.let { it.onBackPressed() }
        }
    }


}
