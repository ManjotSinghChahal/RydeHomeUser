package com.example.rydehomeuser.ui.activities.home.fragment.yourTrips


import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.app.Fragment
import android.support.v4.view.ViewPager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.rydehomedriver.utils.GlobalHelper

import com.example.rydehomeuser.R
import com.example.rydehomeuser.ui.activities.home.Home
import com.example.rydehomeuser.ui.activities.home.fragment.pastTrips.PastTrips
import com.example.rydehomeuser.ui.activities.home.fragment.upcommingTrips.UpcommingTrips
import com.example.rydehomeuser.utils.TabAdapter


class YourTrips : Fragment() {
    lateinit var  viewPager : ViewPager
    lateinit var  tabLayout : TabLayout
    lateinit var  tabAdapter : TabAdapter
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
       val view  = inflater.inflate(R.layout.fragment_your_trips, container, false)




        clickListener(view)
        tabSetup(view)
        GlobalHelper.setToolbar(getString(R.string.your_trips),homeCrossIconVis = true)




        return view
    }



    fun clickListener(view: View )
    {
        Home.homeCrossIcon.setOnClickListener {
            activity?.onBackPressed()
        }
    }
    fun tabSetup(view : View)
    {
        viewPager = view.findViewById(R.id.viewPager_history) as ViewPager
        tabLayout  = view.findViewById(R.id.tabLayout_history) as TabLayout

        tabAdapter = TabAdapter(childFragmentManager,activity)
        tabAdapter.addFragment(PastTrips(getString(R.string.past)),getString(R.string.past))
        tabAdapter.addFragment(UpcommingTrips(getString(R.string.upcoming)),getString(R.string.upcoming))

        viewPager.adapter = tabAdapter
        tabLayout.setupWithViewPager(viewPager)
        highLightCurrentTab(0)




        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener{
            override fun onPageScrollStateChanged(p0: Int) {

            }

            override fun onPageScrolled(p0: Int, p1: Float, p2: Int) {

            }

            override fun onPageSelected(p0: Int) {
                highLightCurrentTab(p0)

            }
        })








    }


    private fun highLightCurrentTab(position: Int) {
        for (i in 0 until tabLayout.tabCount) {
            val tab = tabLayout.getTabAt(i)!!
            tab.customView = null
            tab.customView = tabAdapter.getTabView(i,activity)
        }

        val tab = tabLayout.getTabAt(position)!!
        tab.customView = null
        tab.customView = tabAdapter.getSelectedTabView(position,activity)
    }


}
